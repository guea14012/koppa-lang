#!/usr/bin/env python3
"""
APOLLO Language Runner v2.0
Main entry point with bytecode VM support

Usage:
    apollo run <script.apo>       # Run with VM
    apollo compile <script.apo>   # Compile to bytecode
    apollo repl                   # Interactive REPL
    apollo disasm <script.apo>    # Disassemble bytecode
"""

import sys
import os
import subprocess
import tempfile
from pathlib import Path
from lexer import tokenize
from parser import parse
from compiler import Compiler, Optimizer
from vm import VirtualMachine, VMCompiler
from apollo_opcodes import CodeObject
from deno_compiler import DenoTranspiler


def run_bytecode(filepath: str):
    """Run compiled bytecode (.apc) directly"""
    import pickle
    source_path = Path(filepath)

    if not source_path.exists():
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    try:
        with open(filepath, 'rb') as f:
            code = pickle.load(f)

        if not isinstance(code, CodeObject):
            print(f"Error: Invalid bytecode file: {filepath}")
            sys.exit(1)

        # Execute with VM
        vm = VirtualMachine()
        # Skip 'run_bytecode' and 'file.apc'
        script_args = sys.argv[3:]
        result = vm.run(code, script_args=script_args)

        if result is not None:
            print(f"Result: {result}")

    except Exception as e:
        print(f"Runtime Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def run_deno(filepath: str):
    """Run script using Deno runtime for maximum performance"""
    source_path = Path(filepath)

    if not source_path.exists():
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    source = source_path.read_text()

    try:
        print(f"Transpiling {filepath} to Deno/TypeScript...")
        transpiler = DenoTranspiler()
        js_code = transpiler.transpile(source)

        # Create a temporary directory for execution to handle relative imports
        # We need deno_runtime.ts to be in the same directory as the script
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            
            # Copy runtime to temp dir
            runtime_src = Path(__file__).parent / "deno_runtime.ts"
            runtime_dest = tmp_path / "deno_runtime.ts"
            if runtime_src.exists():
                runtime_dest.write_text(runtime_src.read_text())
            
            # Write transpiled code
            script_path = tmp_path / "main.ts"
            script_path.write_text(js_code)
            
            print(f"Executing with Deno...")
            # Pass remaining CLI args to Deno
            script_args = sys.argv[3:]
            
            cmd = ["deno", "run", "--allow-all", str(script_path)] + script_args
            
            try:
                result = subprocess.run(cmd, capture_output=False, check=True)
            except FileNotFoundError:
                print("Error: 'deno' command not found. Please install Deno (https://deno.land/) for high-performance execution.")
                sys.exit(1)
            except subprocess.CalledProcessError as e:
                print(f"Deno execution failed with exit code {e.returncode}")
                sys.exit(e.returncode)

    except Exception as e:
        print(f"Transpilation Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def run_vm(filepath: str):
    """Run script using bytecode VM"""
    source_path = Path(filepath)

    if not source_path.exists():
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    source = source_path.read_text()

    try:
        # Compile phase
        print(f"Compiling {filepath}...")

        compiler = Compiler()
        optimizer = Optimizer()

        # Compile to bytecode (compiler handles tokenizing/parsing)
        code = compiler.compile(source, filepath)

        # Optimize
        if optimizer.enabled:
            code = optimizer.optimize(code)

        print(f"  Generated {len(code.instructions)} instructions")
        print(f"  Constants: {len(code.constants)}")

        # Execute with VM — pass remaining CLI args to main()
        vm = VirtualMachine()
        script_args = sys.argv[3:]  # argv[0]=apollo.py, argv[1]=run, argv[2]=script
        result = vm.run(code, script_args=script_args)

        if result is not None:
            print(f"Result: {result}")

    except Exception as e:
        print(f"Runtime Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def run_interpreter(filepath: str):
    """Run script using tree-walk interpreter (legacy)"""
    from interpreter import interpret

    source_path = Path(filepath)
    if not source_path.exists():
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    source = source_path.read_text()

    try:
        result = interpret(source)
        if result.value is not None:
            print(f"Result: {result}")
    except Exception as e:
        print(f"Runtime Error: {e}")
        sys.exit(1)


def compile_file(filepath: str, output: str = None):
    """Compile to bytecode file"""
    source_path = Path(filepath)

    if not source_path.exists():
        print(f"Error: File not found: {filepath}")
        sys.exit(1)

    source = source_path.read_text()

    try:
        compiler = Compiler()
        code = compiler.compile(source, filepath)

        # Save bytecode
        if output is None:
            output = filepath.replace(".apo", ".apc")  # APOLLO Compiled

        import pickle
        with open(output, 'wb') as f:
            pickle.dump(code, f)

        print(f"Compiled: {filepath} -> {output}")
        print(f"  Instructions: {len(code.instructions)}")
        print(f"  Constants: {len(code.constants)}")

    except Exception as e:
        print(f"Compile Error: {e}")
        sys.exit(1)


def disasm(filepath: str):
    """Disassemble bytecode"""
    import pickle

    if filepath.endswith(".apo"):
        # Compile first
        source = Path(filepath).read_text()
        compiler = Compiler()
        code = compiler.compile(source, filepath)
    else:
        # Load bytecode
        with open(filepath, 'rb') as f:
            code = pickle.load(f)

    print(f"Disassembly of {filepath}:")
    print(f"Code Object: {code.name}")
    print(f"Constants: {code.constants}")
    print(f"Names: {code.names}")
    print()
    print("Instructions:")

    for i, instr in enumerate(code.instructions):
        print(f"  {i:04d}: {instr}")


def repl():
    """Interactive REPL with VM"""
    print("APOLLO Language VM REPL v2.0")
    print("Type 'exit' to quit, 'help' for help\n")

    vm = VirtualMachine()
    compiler = Compiler()

    while True:
        try:
            line = input("apollo> ")

            if line.strip() == "exit":
                break

            if line.strip() == "help":
                print("APOLLO REPL Commands:")
                print("  exit     - Exit REPL")
                print("  help     - Show this help")
                print("  modules  - List available modules")
                print("  clear    - Clear screen")
                continue

            if line.strip() == "clear":
                os.system("cls" if os.name == "nt" else "clear")
                continue

            if line.strip() == "modules":
                print("Available modules:")
                for name in vm.modules:
                    print(f"  - {name}")
                continue

            try:
                # Compile (handles tokenize + parse internally)
                code = compiler.compile(line)

                # Execute (persistent VM shares globals across REPL lines)
                result = vm.run(code)
                if result is not None:
                    print(f"= {result}")

            except Exception as e:
                print(f"Error: {e}")

        except KeyboardInterrupt:
            print("\nUse 'exit' to quit")
        except EOFError:
            break


def show_version():
    """Show version info"""
    print("APOLLO Language v2.0")
    print("Advanced Penetration Operation Language & Logic Optimizer")
    print()
    print("Architecture:")
    print("  - Lexer: Tokenizes source")
    print("  - Parser: Builds AST")
    print("  - Compiler: Generates bytecode")
    print("  - VM: Stack-based execution engine")
    print()
    print("Security Modules:")
    print("  - log: Logging primitives")
    print("  - scan: Network scanning")
    print("  - crypto: Cryptographic functions")
    print("  - io: File and system I/O")


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        show_version()
        print("\nUsage:")
        print("  apollo run <script.apo>        - Run with VM (recommended)")
        print("  apollo deno <script.apo>       - Run with Deno (maximum performance)")
        print("  apollo interp <script.apo>     - Run with interpreter (legacy)")
        print("  apollo compile <script.apo>    - Compile to bytecode")
        print("  apollo disasm <file>           - Disassemble bytecode")
        print("  apollo repl                    - Start VM REPL")
        print("  apollo version                 - Show version info")
        sys.exit(0)

    command = sys.argv[1]

    if command == "run":
        if len(sys.argv) < 3:
            print("Error: No input file specified")
            sys.exit(1)
        run_vm(sys.argv[2])

    elif command == "run_bytecode":
        if len(sys.argv) < 3:
            print("Error: No input file specified")
            sys.exit(1)
        run_bytecode(sys.argv[2])

    elif command == "deno":
        if len(sys.argv) < 3:
            print("Error: No input file specified")
            sys.exit(1)
        run_deno(sys.argv[2])

    elif command == "interp":
        if len(sys.argv) < 3:
            print("Error: No input file specified")
            print("Usage: apollo interp <script.apo>")
            sys.exit(1)
        run_interpreter(sys.argv[2])

    elif command == "compile":
        if len(sys.argv) < 3:
            print("Error: No input file specified")
            sys.exit(1)
        output = sys.argv[3] if len(sys.argv) > 3 else None
        compile_file(sys.argv[2], output)

    elif command == "disasm":
        if len(sys.argv) < 3:
            print("Error: No input file specified")
            sys.exit(1)
        disasm(sys.argv[2])

    elif command == "repl":
        repl()

    elif command == "version":
        show_version()

    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()

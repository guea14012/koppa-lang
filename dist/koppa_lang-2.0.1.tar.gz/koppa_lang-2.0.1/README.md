# KOPPA Language

**AP**hysical **P**enetration **O**peration **L**anguage & **L**ogic **O**ptimizer

A domain-specific programming language designed for security professionals and penetration testers.

## Overview

APOLLO combines the best features from multiple languages to create a powerful pentesting DSL:

| Feature | Inspired By | Purpose |
|---------|-------------|---------|
| Readable syntax | Python | Easy to write and audit |
| Pipeline operator | Bash/PowerShell | Chain security operations |
| Pattern matching | Rust | Clean control flow |
| Object pipeline | PowerShell | Everything is an object |
| System integration | Bash | Execute any tool |
| Type safety | Rust | Optional type annotations |
| Async/await | JavaScript | Concurrent scanning |
| Embeddability | Lua | Lightweight runtime |

## Quick Start

```bash
# Run with optimized VM (Python)
python src/apollo.py run examples/port_scanner.apo

# Run with maximum performance (Deno)
python src/apollo.py deno examples/port_scanner.apo

# Start REPL
python src/apollo.py repl
```

## Hello World

```apollo
#!/usr/bin/apollo

import scan, log

fn main() {
    let target = "scanme.nmap.org"
    let ports = [22, 80, 443]

    log.info("Scanning {target}")

    for port in ports {
        if scan.tcp(target, port) {
            log.info("[+] Port {port} is open - {scan.service(port)}")
        }
    }

    target
        |> scan.tcp(ports)
        |> filter(open_ports)
        |> save("results.json")
}
```

## Key Features

### Pipeline Operator

Chain security operations fluently:

```apollo
target
    |> recon.dns()
    |> scan.tcp(ports)
    |> enum.services()
    |> exploit.match()
    |> report.save()
```

### Security Primitives

Built-in modules for common pentesting operations:

```apollo
import recon, scan, enum, exploit, crypto, report

# Reconnaissance
recon.whois(domain)
recon.dns_enumerate(domain)

# Scanning
scan.tcp(host, ports)
scan.version(host, ports)

# Enumeration
enum.smb_shares(host)
enum.ldap_users(dc)
enum.http_directories(url, wordlist)

# Cryptography
crypto.hash.md5(data)
crypto.hash.ntlm(password)
crypto.encode.base64(data)
```

### Pattern Matching

Clean control flow with Rust-style match:

```apollo
match service {
    "http" => http.scan(target),
    "https" => tls.scan(target),
    "ssh" => ssh.brute(target, wordlist),
    "smb" => smb.enum_shares(target),
    _ => log.info("Unknown service")
}
```

### Async/Parallel Execution

Run multiple operations concurrently:

```apollo
async fn mass_scan(targets) -> Stream {
    parallel {
        for target in targets {
            emit scan_port(target)
        }
    }
}
```

### Error Handling

Rust-style Result types:

```apollo
fn crack_hash(hash) -> Result {
    let result = crypto.crack(hash, wordlist)

    if result.cracked {
        Ok(result.plaintext)
    } else {
        Err("Hash not cracked")
    }
}

# Usage
match crack_hash(hash) {
    Ok(password) => log.info("Found: {password}"),
    Err(e) => log.error("Failed: {e}")
}
```

## Architecture

```
APOLLO/
├── src/
│   ├── lexer.py       # Tokenizer
│   ├── parser.py      # AST builder
│   ├── interpreter.py # Runtime executor
│   └── apollo.py      # CLI runner
├── stdlib/
│   ├── recon.apo   # Reconnaissance module
│   ├── scan.apo    # Scanning module
│   ├── vuln.apo    # Vulnerability scanning (XSS, SQLi, LFI)
│   ├── crypto.apo  # Cryptography module
│   └── ...
├── examples/
│   ├── port_scanner.apo
│   ├── web_scanner.apo
│   ├── ad_enum.apo
│   └── password_cracker.apo
└── docs/
    ├── LANGUAGE_SPEC.md
    └── GETTING_STARTED.md
```

## Example Scripts

### Port Scanner

```apollo
#!/usr/bin/apollo
import scan, log

let COMMON_PORTS = [21, 22, 23, 80, 443, 445, 3389]

fn main(args) {
    let target = args[0] | default("127.0.0.1")

    for port in COMMON_PORTS {
        if scan.tcp(target, port) {
            log.info("[+] {port}: {scan.service(port)}")
        }
    }
}
```

### Web Vulnerability Scanner

```apollo
#!/usr/bin/apollo
import http, enum, report, log

let XSS_PAYLOADS = ["<script>alert('XSS')</script>", "<img src=x onerror=alert(1)>"]

async fn check_xss(url, param) -> Stream {
    for payload in XSS_PAYLOADS {
        let response = http.get("{url}?{param}={payload}")
        if response.body.contains(payload) {
            emit report.finding("XSS", "high", "Reflected: {payload}")
        }
    }
}

fn main(args) {
    let target = args[0]
    let params = ["search", "q", "query"]

    parallel {
        for param in params {
            check_xss(target, param)
        }
    } |> report.save("xss_report.html")
}
```

### AD Enumeration

```apollo
#!/usr/bin/apollo
import enum, recon, log

fn enumerate_ad(domain, dc) {
    let data = {
        users: enum.ldap_users(dc),
        shares: enum.smb_shares(dc),
        kerberoastable: enum.kerberoastable(dc),
    }

    for user in data.kerberoastable {
        log.warn("Kerberoastable: {user.spn}")
    }

    return data
}

fn main(args) {
    let domain = args.domain | default("LOCAL")
    enumerate_ad(domain) |> save("ad_enum.json")
}
```

## Documentation

- [Language Specification](docs/LANGUAGE_SPEC.md) - Full syntax reference
- [Getting Started](docs/GETTING_STARTED.md) - Tutorial and examples
- [Standard Library](stdlib/) - Built-in modules

## Running Scripts

```bash
# Run a script
python src/apollo.py run examples/port_scanner.apo

# Tokenize and show tokens
python src/apollo.py lex script.apo

# Parse and show AST
python src/apollo.py parse script.apo

# Start REPL
python src/apollo.py repl
```

## Design Goals

1. **Security-First**: Built-in primitives for pentesting operations
2. **Cross-Platform**: Works on Windows, Linux, and macOS
3. **Readable**: Clean syntax that's easy to audit
4. **Composable**: Pipeline operator for chaining operations
5. **Safe by Default**: Dangerous operations require explicit opt-in
6. **Extensible**: FFI to call Python, system tools, and external libraries

## Roadmap

- [x] Native compiler (via Deno transpilation)
- [x] JIT compilation for performance (via V8/Deno)
- [ ] More stdlib modules (exploit, post, lateral)
- [ ] Package manager for community modules
- [ ] LSP support for IDE integration
- [ ] Debugger with breakpoints and stepping

## License

MIT License - See LICENSE file for details

---

**APOLLO** - Built for security professionals, by security professionals.
